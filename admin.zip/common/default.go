package common

const (
	// 密码盐码
	SECRET_KEY = ",sdi_FEer=g*%^FDivre_/hsaf;..sfoijfe_+isdf{i3"
	// aes盐码
	SECRET_AES_KEY = "O8Hp9WQbFPT0b5AUsEMVLtIU1MVYOrt5"
	// token盐码
	SECRET_TOKEN_KEY = "fDEtrkpbQbocVxYRLZrnkrXDWJzRZMfO"
	// 分页页码
	PAGE_SIZE = 10
)
