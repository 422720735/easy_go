gulp 自动化构建工具

全局安装 gulp
npm install --g gulp

安装依赖
npm install

开发环境
npm run dev

生产环境
npm run build
