/**
 * 路由接口
 * */
const HOST = '/api'
const Ok = 1
const Err = 0